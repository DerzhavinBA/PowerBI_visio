const {test}=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const {environment}=require('./helpers/host.cjs');
test('entire recovered plugin renders forecast and connects tooltip/context/selection',async()=>{
 const e=environment(fs.readFileSync('.tmp/visual.js','utf8'));
 try{
  e.visual.update(e.data());await e.flush();
  assert.equal(e.errors.length,0,e.errors.map(x=>x.stack).join('\n'));
  assert.equal(e.element.querySelectorAll('.forecast-extension').length,1);
  assert.equal(e.element.querySelectorAll('.forecast-marker').length,2);
  const n=e.element.querySelector('.forecast-extension');
  n.dispatchEvent(new e.w.MouseEvent('click',{bubbles:true,ctrlKey:true}));await Promise.resolve();assert.equal(e.events.clicks.at(-1).key,'task-0');assert.equal(e.events.clicks.at(-1).multi,true);
  n.dispatchEvent(new e.w.MouseEvent('contextmenu',{bubbles:true}));assert.equal(e.events.menus.at(-1).id.getKey(),'task-0');
  assert.ok(e.visual.getTooltipData(n.__data__).some(x=>x.displayName==='Окончание прогноз'));
  const model=e.visual.getFormattingModel();assert.ok(model.cards.length>=5);
 }finally{e.close();}
});
test('without forecast core geometry and legacy enumeration match original',async()=>{
 const base=environment(fs.readFileSync('vendor/visual.js','utf8')),updated=environment(fs.readFileSync('.tmp/visual.js','utf8'));
 try{
  base.visual.update(base.data(false));updated.visual.update(updated.data(false));await Promise.all([base.flush(),updated.flush()]);
  const geometry=e=>[...e.element.querySelectorAll('.barColShape,.barColCol')].map(n=>['x','y','width','height','d','fill'].map(a=>n.getAttribute(a)));
  assert.ok(geometry(base).length);assert.deepEqual(geometry(updated),geometry(base));assert.equal(updated.element.querySelector('.forecast'),null);
  assert.equal(JSON.stringify(updated.visual.enumerateObjectInstances({objectName:'textValues'})),JSON.stringify(base.visual.enumerateObjectInstances({objectName:'textValues'})));
 }finally{base.close();updated.close();}
});
test('five levels keep forecasts on leaves only; collapse and row filtering do not attach dates to parents',async()=>{
 const e=environment(fs.readFileSync('.tmp/visual.js','utf8'));
 try{
  const data=e.data(),view=data.dataViews[0],cats=view.categorical.categories;
  cats[0].values=['Раздел','Раздел'];
  for(let level=1;level<5;level++)cats.push({source:{displayName:'Уровень '+level,queryName:'Tasks.Level'+level,roles:{items:true},rolesIndex:{items:[level]},type:{text:true},index:cats.length},values:level===4?['Работа А','Работа Б']:['Этап '+level,'Этап '+level],identity:cats[0].identity});
  view.metadata.columns=cats.map(c=>c.source);
  e.visual.update(data);await e.flush();
  assert.equal(e.element.querySelectorAll('.forecast-marker').length,2);
  for(const marker of e.element.querySelectorAll('.forecast-marker'))assert.equal(e.visual.isCalculatedItem(marker.__data__),false);
  const calculated=e.visual.viewModel.dataPoints.find(p=>e.visual.isCalculatedItem(p));assert.ok(calculated);
  e.visual.wrappingFilter=[calculated.group+'||'+calculated.subgroup+'||'+calculated.levelName];e.visual.updateImmediate(data,true);await e.flush();
  assert.equal(e.element.querySelectorAll('.forecast-marker').length,0);
  e.visual.wrappingFilter=[];
  const filtered={...data,dataViews:[{...view,categorical:{categories:cats.map(c=>({...c,values:[c.values[1]],identity:[c.identity[1]]}))}}]};
  e.visual.updateImmediate(filtered,true);await e.flush();
  assert.equal(e.element.querySelectorAll('.forecast-marker').length,1);assert.equal(e.element.querySelector('.forecast-marker').__data__.selectionId.getKey(),'task-1');
 }finally{e.close();}
});
test('emitted formatting model type-checks against official Power BI 5.1 declarations',()=>{
 const e=environment(fs.readFileSync('.tmp/visual.js','utf8'));
 try{
  e.visual.update(e.data());const model=e.visual.getFormattingModel();
  fs.writeFileSync('.tmp/formatting-contract.ts',"import powerbi from 'powerbi-visuals-api';\nconst model: powerbi.visuals.FormattingModel = "+JSON.stringify(model,null,2)+';\n');
  require('node:child_process').execFileSync(process.execPath,[require.resolve('typescript/bin/tsc'),'--noEmit','--skipLibCheck','--esModuleInterop','--target','ES2020','--moduleResolution','node','.tmp/formatting-contract.ts'],{stdio:'pipe'});
 }finally{e.close();}
});
test('empty first update shows instructions and accepts subsequent valid data',async()=>{
 const e=environment(fs.readFileSync('.tmp/visual.js','utf8'));
 try{e.visual.update({type:2,viewMode:1,viewport:{width:800,height:400},dataViews:[]});assert.ok(e.visual.getFormattingModel().cards.length);e.visual.update(e.data());await e.flush();assert.equal(e.element.querySelectorAll('.forecast-marker').length,2);}finally{e.close();}
});
