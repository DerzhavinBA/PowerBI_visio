const fs=require('node:fs');
// Reuse the exact host/data fixture, replacing only jsdom setup with the real browser.
const source=fs.readFileSync('tests/helpers/host.cjs','utf8');
const host=source.slice(source.indexOf(' let selections=[];'),source.indexOf(' return {w,dom,visual'));
const html=`<!doctype html><html lang="ru"><meta charset="utf-8"><title>Гантт ТМХИ — проверка прогноза</title>
<style>body{margin:24px;font:15px Calibri,Segoe UI,sans-serif;color:#242424}h1{color:#004F9E;font-size:24px}p{max-width:1000px}#visual{position:relative;width:min(100%,1000px);height:260px;border:1px solid #ccc}button{margin:8px;padding:8px}#status{white-space:pre-wrap}</style>
<link rel="stylesheet" href="../.tmp/visual.css"><h1>План и прогноз завершения</h1><p>Локальная проверка реального кода визуала с имитацией API хоста. Это не проверка в Power BI. Работа А — поздний прогноз, работа Б — ранний.</p><button id="toggle">Без прогноза / с прогнозом</button><button id="contrast">Высокий контраст</button><button id="labels">Подписи дат</button><div id="visual"></div><pre id="status"></pre>
<script>window.powerbi={visuals:{plugins:{}}};</script><script src="../.tmp/visual.js"></script><script>
const w=window;${host}
let forecast=true,contrast=false,labels=false;function draw(){const e=data(forecast);e.viewport={width:element.clientWidth,height:260};e.dataViews[0].metadata.objects.forecast={show:true,showLabel:labels};e.dataViews[0].metadata.objects.textValues={show:true,defaultColorA:{solid:{color:"#004F9E"}},barsOffset:45};e.dataViews[0].metadata.objects.zooming={focusOnToday:false,verticalZoomByItemSize:true,verticalZoomItemSize:48};host.colorPalette.isHighContrast=contrast;host.colorPalette.foreground.value=contrast?'#FFFFFF':'#242424';host.colorPalette.background.value=contrast?'#000000':'#FFFFFF';element.style.background=contrast?'#000000':'#FFFFFF';visual.update(e);setTimeout(()=>{document.querySelector('#status').textContent='Продолжений: '+element.querySelectorAll('.forecast-extension').length+'; маркеров: '+element.querySelectorAll('.forecast-marker').length+'; карточек настроек: '+visual.getFormattingModel().cards.length;},1500);}
document.querySelector('#toggle').onclick=()=>{forecast=!forecast;draw()};document.querySelector('#contrast').onclick=()=>{contrast=!contrast;draw()};document.querySelector('#labels').onclick=()=>{labels=!labels;draw()};draw();
</script></html>`;
fs.writeFileSync('docs/preview.html',html);console.log('docs/preview.html');
